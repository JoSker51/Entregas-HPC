import requests
import json

# URL del API
API_URL = "http://localhost:5000"

def test_health():
    """Prueba el endpoint de salud"""
    print("\n=== Test 1: Health Check ===")
    try:
        response = requests.get(f"{API_URL}/health")
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.json()}")
        return response.status_code == 200
    except Exception as e:
        print(f"Error: {e}")
        return False

def test_calculate_distance():
    """Prueba el cálculo de distancia con una ruta simple"""
    print("\n=== Test 2: Calculate Distance ===")
    
    # Ruta de ejemplo: A -> B -> C
    cities = [
        {"name": "A", "x": 0, "y": 0},
        {"name": "B", "x": 3, "y": 4},
        {"name": "C", "x": 6, "y": 0}
    ]
    
    try:
        response = requests.post(
            f"{API_URL}/calculate_distance",
            json={"cities": cities}
        )
        
        print(f"Status Code: {response.status_code}")
        result = response.json()
        print(f"Response: {json.dumps(result, indent=2)}")
        
        # Verificar cálculo manual
        # A -> B: sqrt((3-0)² + (4-0)²) = sqrt(9 + 16) = sqrt(25) = 5
        # B -> C: sqrt((6-3)² + (0-4)²) = sqrt(9 + 16) = sqrt(25) = 5
        # Total esperado: 10
        
        expected_distance = 10.0
        actual_distance = result['total_distance']
        
        print(f"\nDistancia esperada: {expected_distance}")
        print(f"Distancia calculada: {actual_distance}")
        
        if abs(actual_distance - expected_distance) < 0.01:
            print("✓ Cálculo correcto!")
            return True
        else:
            print("✗ Error en el cálculo")
            return False
            
    except Exception as e:
        print(f"Error: {e}")
        return False

def test_multiple_cities():
    """Prueba con más ciudades"""
    print("\n=== Test 3: Multiple Cities ===")
    
    cities = [
        {"name": "A", "x": 0, "y": 0},
        {"name": "B", "x": 3, "y": 4},
        {"name": "C", "x": 6, "y": 0},
        {"name": "D", "x": 3, "y": -4},
        {"name": "E", "x": -3, "y": 2}
    ]
    
    try:
        response = requests.post(
            f"{API_URL}/calculate_distance",
            json={"cities": cities}
        )
        
        print(f"Status Code: {response.status_code}")
        result = response.json()
        print(f"Response: {json.dumps(result, indent=2)}")
        print(f"Ruta: {' -> '.join(result['route'])}")
        
        return response.status_code == 200
        
    except Exception as e:
        print(f"Error: {e}")
        return False

def test_error_handling():
    """Prueba el manejo de errores"""
    print("\n=== Test 4: Error Handling ===")
    
    # Test con datos inválidos
    test_cases = [
        {"name": "Sin ciudades", "data": {}},
        {"name": "Ciudad sin coordenadas", "data": {"cities": [{"name": "A"}]}},
        {"name": "Una sola ciudad", "data": {"cities": [{"name": "A", "x": 0, "y": 0}]}}
    ]
    
    for test in test_cases:
        print(f"\n  {test['name']}:")
        try:
            response = requests.post(
                f"{API_URL}/calculate_distance",
                json=test['data']
            )
            print(f"  Status Code: {response.status_code}")
            print(f"  Response: {response.json()}")
        except Exception as e:
            print(f"  Error: {e}")

def main():
    print("=" * 60)
    print("PRUEBAS DEL API - PROBLEMA DEL VIAJANTE")
    print("=" * 60)
    
    tests_passed = 0
    total_tests = 3
    
    if test_health():
        tests_passed += 1
    
    if test_calculate_distance():
        tests_passed += 1
    
    if test_multiple_cities():
        tests_passed += 1
    
    test_error_handling()
    
    print("\n" + "=" * 60)
    print(f"RESULTADOS: {tests_passed}/{total_tests} pruebas exitosas")
    print("=" * 60)

if __name__ == "__main__":
    main()