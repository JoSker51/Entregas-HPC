import requests
import itertools
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import json

# Configuración
API_URL = "http://localhost:5000/calculate_distance"
MAX_WORKERS = 10  # Número de hilos concurrentes

# Definir las ciudades a visitar
CITIES = [
    {"name": "A", "x": 0, "y": 0},
    {"name": "B", "x": 3, "y": 4},
    {"name": "C", "x": 6, "y": 0},
    {"name": "D", "x": 3, "y": -4},
    {"name": "E", "x": -3, "y": 2}
]

def calculate_route_distance(route):
    """
    Envía una ruta al API y obtiene la distancia total.
    
    Args:
        route: Lista de ciudades ordenadas
    
    Returns:
        tuple: (distancia, ruta) o (None, None) si hay error
    """
    try:
        payload = {"cities": list(route)}
        response = requests.post(API_URL, json=payload, timeout=5)
        
        if response.status_code == 200:
            data = response.json()
            return data['total_distance'], [city['name'] for city in route]
        else:
            print(f"Error en API: {response.status_code}")
            return None, None
            
    except requests.exceptions.RequestException as e:
        print(f"Error de conexión: {e}")
        return None, None

def brute_force_sequential():
    """
    Método secuencial: procesa todas las permutaciones una por una.
    """
    print("\n=== BÚSQUEDA SECUENCIAL ===")
    start_time = time.time()
    
    best_distance = float('inf')
    best_route = None
    total_routes = 0
    
    # Generar todas las permutaciones
    for route in itertools.permutations(CITIES):
        distance, route_names = calculate_route_distance(route)
        
        if distance is not None:
            total_routes += 1
            
            if distance < best_distance:
                best_distance = distance
                best_route = route_names
                print(f"Nueva mejor ruta encontrada: {' -> '.join(best_route)} = {best_distance:.2f}")
    
    elapsed_time = time.time() - start_time
    
    print(f"\n--- RESULTADOS SECUENCIALES ---")
    print(f"Rutas evaluadas: {total_routes}")
    print(f"Mejor ruta: {' -> '.join(best_route)}")
    print(f"Distancia óptima: {best_distance:.2f}")
    print(f"Tiempo total: {elapsed_time:.2f} segundos")
    print(f"Promedio por ruta: {(elapsed_time/total_routes)*1000:.2f} ms")
    
    return best_route, best_distance, elapsed_time

def brute_force_parallel():
    """
    Método paralelo: usa ThreadPoolExecutor para procesar múltiples rutas simultáneamente.
    """
    print("\n=== BÚSQUEDA PARALELA ===")
    start_time = time.time()
    
    best_distance = float('inf')
    best_route = None
    total_routes = 0
    
    # Generar todas las permutaciones
    all_routes = list(itertools.permutations(CITIES))
    
    # Procesar en paralelo
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        # Enviar todas las tareas
        future_to_route = {
            executor.submit(calculate_route_distance, route): route 
            for route in all_routes
        }
        
        # Procesar resultados a medida que se completan
        for future in as_completed(future_to_route):
            distance, route_names = future.result()
            
            if distance is not None:
                total_routes += 1
                
                if distance < best_distance:
                    best_distance = distance
                    best_route = route_names
                    print(f"Nueva mejor ruta encontrada: {' -> '.join(best_route)} = {best_distance:.2f}")
    
    elapsed_time = time.time() - start_time
    
    print(f"\n--- RESULTADOS PARALELOS ---")
    print(f"Rutas evaluadas: {total_routes}")
    print(f"Mejor ruta: {' -> '.join(best_route)}")
    print(f"Distancia óptima: {best_distance:.2f}")
    print(f"Tiempo total: {elapsed_time:.2f} segundos")
    print(f"Promedio por ruta: {(elapsed_time/total_routes)*1000:.2f} ms")
    print(f"Hilos usados: {MAX_WORKERS}")
    
    return best_route, best_distance, elapsed_time

def verify_api_connection():
    """Verifica que el API esté disponible"""
    try:
        response = requests.get("http://localhost:5000/health", timeout=2)
        if response.status_code == 200:
            print("✓ Conexión con API establecida")
            return True
    except:
        pass
    
    print("✗ No se puede conectar con el API")
    print("  Asegúrate de que el servicio esté corriendo en http://localhost:5000")
    return False

def main():
    print("=" * 60)
    print("PROBLEMA DEL VIAJANTE - BÚSQUEDA POR FUERZA BRUTA")
    print("=" * 60)
    
    # Mostrar información de las ciudades
    print(f"\nCiudades a visitar: {len(CITIES)}")
    for city in CITIES:
        print(f"  - {city['name']}: ({city['x']}, {city['y']})")
    
    print(f"\nTotal de permutaciones posibles: {len(list(itertools.permutations(CITIES)))}")
    
    # Verificar conexión
    if not verify_api_connection():
        return
    
    # Ejecutar búsqueda secuencial
    seq_route, seq_distance, seq_time = brute_force_sequential()
    
    # Ejecutar búsqueda paralela
    par_route, par_distance, par_time = brute_force_parallel()
    
    # Comparación
    print("\n" + "=" * 60)
    print("COMPARACIÓN DE RENDIMIENTO")
    print("=" * 60)
    print(f"Tiempo secuencial:  {seq_time:.2f} segundos")
    print(f"Tiempo paralelo:    {par_time:.2f} segundos")
    print(f"Speedup:            {seq_time/par_time:.2f}x")
    print(f"Mejora:             {((seq_time-par_time)/seq_time)*100:.1f}%")
    
    # Guardar resultados
    results = {
        "cities": CITIES,
        "sequential": {
            "route": seq_route,
            "distance": seq_distance,
            "time": seq_time
        },
        "parallel": {
            "route": par_route,
            "distance": par_distance,
            "time": par_time,
            "workers": MAX_WORKERS
        }
    }
    
    with open('results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print("\n✓ Resultados guardados en 'results.json'")

if __name__ == "__main__":
    main()