from flask import Flask, request, jsonify
import math
import logging

app = Flask(__name__)

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def calculate_euclidean_distance(city1, city2):
    """
    Calcula la distancia euclidiana entre dos ciudades.
    
    Args:
        city1: Dict con 'x' y 'y' como coordenadas
        city2: Dict con 'x' y 'y' como coordenadas
    
    Returns:
        float: Distancia euclidiana
    """
    x1, y1 = city1['x'], city1['y']
    x2, y2 = city2['x'], city2['y']
    
    distance = math.sqrt((x2 - x1)**2 + (y2 - y1)**2)
    return distance

@app.route('/health', methods=['GET'])
def health_check():
    """Endpoint para verificar que el servicio está activo"""
    return jsonify({"status": "healthy"}), 200

@app.route('/calculate_distance', methods=['POST'])
def calculate_distance():
    """
    Calcula la distancia total de una ruta dada.
    
    Input JSON:
    {
        "cities": [
            {"name": "A", "x": 0, "y": 0},
            {"name": "B", "x": 1, "y": 1},
            ...
        ]
    }
    
    Output JSON:
    {
        "total_distance": 123.45,
        "route": ["A", "B", "C"]
    }
    """
    try:
        data = request.get_json()
        
        if not data or 'cities' not in data:
            return jsonify({"error": "Se requiere una lista de ciudades"}), 400
        
        cities = data['cities']
        
        if len(cities) < 2:
            return jsonify({"error": "Se requieren al menos 2 ciudades"}), 400
        
        # Validar que cada ciudad tenga las coordenadas necesarias
        for city in cities:
            if 'x' not in city or 'y' not in city:
                return jsonify({"error": "Cada ciudad debe tener coordenadas 'x' y 'y'"}), 400
        
        # Calcular distancia total
        total_distance = 0.0
        route_names = []
        
        for i in range(len(cities)):
            route_names.append(cities[i].get('name', f'City_{i}'))
            
            if i < len(cities) - 1:
                distance = calculate_euclidean_distance(cities[i], cities[i + 1])
                total_distance += distance
                logger.info(f"Distancia de {cities[i].get('name')} a {cities[i+1].get('name')}: {distance:.2f}")
        
        logger.info(f"Distancia total calculada: {total_distance:.2f}")
        
        return jsonify({
            "total_distance": round(total_distance, 2),
            "route": route_names,
            "num_cities": len(cities)
        }), 200
        
    except Exception as e:
        logger.error(f"Error al calcular distancia: {str(e)}")
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)